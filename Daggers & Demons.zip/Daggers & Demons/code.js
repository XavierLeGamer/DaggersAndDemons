//Adding letters to the name when a button is hit, changing letters with caps lock, etc.
var alphabetEn = ["a", "b", "d", "c", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
var alphabetCap = false;
onEvent("playerNameA1", "click", function( ) {
  playerNextLetter = getText("playerNameA2");
  nameChange();
});
onEvent("playerNameB1", "click", function( ) {
  playerNextLetter = getText("playerNameB2");
  nameChange();
});
onEvent("playerNameC1", "click", function( ) {
  playerNextLetter = getText("playerNameC2");
  nameChange();
});
onEvent("playerNameD1", "click", function( ) {
  playerNextLetter = getText("playerNameD2");
  nameChange();
});
onEvent("playerNameE1", "click", function( ) {
  playerNextLetter = getText("playerNameE2");
  nameChange();
});
onEvent("playerNameF1", "click", function( ) {
  playerNextLetter = getText("playerNameF2");
  nameChange();
});
onEvent("playerNameG1", "click", function( ) {
  playerNextLetter = getText("playerNameG2");
  nameChange();
});
onEvent("playerNameH1", "click", function( ) {
  playerNextLetter = getText("playerNameH2");
  nameChange();
});
onEvent("playerNameI1", "click", function( ) {
  playerNextLetter = getText("playerNameI2");
  nameChange();
});
onEvent("playerNameJ1", "click", function( ) {
  playerNextLetter = getText("playerNameJ2");
  nameChange();
});
onEvent("playerNameK1", "click", function( ) {
  playerNextLetter = getText("playerNameK2");
  nameChange();
});
onEvent("playerNameL1", "click", function( ) {
  playerNextLetter = getText("playerNameL2");
  nameChange();
});
onEvent("playerNameM1", "click", function( ) {
  playerNextLetter = getText("playerNameM2");
  nameChange();
});
onEvent("playerNameN1", "click", function( ) {
  playerNextLetter = getText("playerNameN2");
  nameChange();
});
onEvent("playerNameO1", "click", function( ) {
  playerNextLetter = getText("playerNameO2");
  nameChange();
});
onEvent("playerNameP1", "click", function( ) {
  playerNextLetter = getText("playerNameP2");
  nameChange();
});
onEvent("playerNameQ1", "click", function( ) {
  playerNextLetter = getText("playerNameQ2");
  nameChange();
});
onEvent("playerNameR1", "click", function( ) {
  playerNextLetter = getText("playerNameR2");
  nameChange();
});
onEvent("playerNameS1", "click", function( ) {
  playerNextLetter = getText("playerNameS2");
  nameChange();
});
onEvent("playerNameT1", "click", function( ) {
  playerNextLetter = getText("playerNameT2");
  nameChange();
});
onEvent("playerNameU1", "click", function( ) {
  playerNextLetter = getText("playerNameU2");
  nameChange();
});
onEvent("playerNameV1", "click", function( ) {
  playerNextLetter = getText("playerNameV2");
  nameChange();
});
onEvent("playerNameW1", "click", function( ) {
  playerNextLetter = getText("playerNameW2");
  nameChange();
});
onEvent("playerNameX1", "click", function( ) {
  playerNextLetter = getText("playerNameX2");
  nameChange();
});
onEvent("playerNameY1", "click", function( ) {
  playerNextLetter = getText("playerNameY2");
  nameChange();
});
onEvent("playerNameZ1", "click", function( ) {
  playerNextLetter = getText("playerNameZ2");
  nameChange();
});
var playerNextLetter = "";
function nameChange() {
  if (playerName2.length < 14) {
    appendItem(playerName2, playerNextLetter);
    playerName1 = playerName2.join("");
    setText("playerName(result)", playerName1);
  }
}
onEvent("playerNameBackspace1", "click", function( ) {
  if (playerName2.length > 0) {
    removeItem(playerName2, playerName2.length - 1);
    playerName1 = playerName2.join("");
    setText("playerName(result)", playerName1);
  }
});
for (var i = 0; i <= 25; i++) {
  setText("playerName" + (alphabetEn[i].toUpperCase() + "2"), alphabetEn[i]);
}
onEvent("playerNameCapsLock1", "click", function( ) {
  if (alphabetCap == false) {
    alphabetCap = true;
    alphabetEn = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
    for (var i = 0; i <= 25; i++) {
      setText("playerName" + (alphabetEn[i].toUpperCase() + "2"), alphabetEn[i]);
    }
  } else {
    alphabetCap = false;
    alphabetEn = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
    for (var i = 0; i <= 25; i++) {
      setText("playerName" + (alphabetEn[i].toUpperCase() + "2"), alphabetEn[i]);
    }
  }
});
//Example: "S1A3T2" Saga 1, Arc 3, Text 2
var partInStory = "S0A1T1";
//Default player name, if not given, is Josh
var playerName2 = ["J", "o", "s", "h"];
var playerName1 = playerName2.join("");
//Setting up items, which will be a massive pain later
var itemTypes = ["Weapon", "Armor", "Tool", "Extra"];
var itemIds = [0001, 0002, 0003, 0004];
var itemNam = ["Metal Pipe", "Life Jacket", "Compass", "Sunglasses"];
//Resetting the size of some elements in case they aren't locked
setPosition("mainPlayButton", 170, 310, 107, 40);
setPosition("choosingNameConf1", 105, 370, 110, 25);
setPosition("choosingNameConf2", 105, 360, 110, 45);
setPosition("startSettingsConf2", 105, 330, 110, 25);
setSize("dialogue(txtS0A1T1)", 320, 60);
setSize("dialogue(txtS0A1T2)", 320, 60);
setSize("dialogue(txtS0A1T3)", 320, 60);
setSize("dialogue(txtS0A1T4)", 320, 75);
setSize("dialogue(1contS0A1)", 320, 60);
setSize("dialogue(2contS0A1)", 320, 90);
setProperty("dialogue(1contS0A1)", "text", "Struggle to stay conscious..?");
setPosition("playerNameQ1", 0, 170, 40, 40);
setPosition("playerNameQ2", getProperty("playerNameQ1", "x"), getProperty("playerNameQ1", "y") + 10, 35, 20);
setPosition("playerNameW1", 40, 170, 40, 40);
setPosition("playerNameW2", getProperty("playerNameW1", "x"), getProperty("playerNameW1", "y") + 10, 35, 20);
setPosition("playerNameE1", 80, 170, 40, 40);
setPosition("playerNameE2", getProperty("playerNameE1", "x"), getProperty("playerNameE1", "y") + 10, 35, 20);
setPosition("playerNameR1", 120, 170, 40, 40);
setPosition("playerNameR2", getProperty("playerNameR1", "x"), getProperty("playerNameR1", "y") + 10, 35, 20);
setPosition("playerNameT1", 160, 170, 40, 40);
setPosition("playerNameT2", getProperty("playerNameT1", "x"), getProperty("playerNameT1", "y") + 10, 35, 20);
setPosition("playerNameY1", 200, 170, 40, 40);
setPosition("playerNameY2", getProperty("playerNameY1", "x"), getProperty("playerNameY1", "y") + 10, 35, 20);
setPosition("playerNameU1", 240, 170, 40, 40);
setPosition("playerNameU2", getProperty("playerNameU1", "x"), getProperty("playerNameU1", "y") + 10, 35, 20);
setPosition("playerNameI1", 280, 170, 40, 40);
setPosition("playerNameI2", getProperty("playerNameI1", "x"), getProperty("playerNameI1", "y") + 10, 35, 20);
setPosition("playerNameO1", 0, 210, 40, 40);
setPosition("playerNameO2", getProperty("playerNameO1", "x"), getProperty("playerNameO1", "y") + 10, 35, 20);
setPosition("playerNameP1", 40, 210, 40, 40);
setPosition("playerNameP2", getProperty("playerNameP1", "x"), getProperty("playerNameP1", "y") + 10, 35, 20);
setPosition("playerNameA1", 80, 210, 40, 40);
setPosition("playerNameA2", getProperty("playerNameA1", "x"), getProperty("playerNameA1", "y") + 10, 35, 20);
setPosition("playerNameS1", 120, 210, 40, 40);
setPosition("playerNameS2", getProperty("playerNameS1", "x"), getProperty("playerNameS1", "y") + 10, 35, 20);
setPosition("playerNameD1", 160, 210, 40, 40);
setPosition("playerNameD2", getProperty("playerNameD1", "x"), getProperty("playerNameD1", "y") + 10, 35, 20);
setPosition("playerNameF1", 200, 210, 40, 40);
setPosition("playerNameF2", getProperty("playerNameF1", "x"), getProperty("playerNameF1", "y") + 10, 35, 20);
setPosition("playerNameG1", 240, 210, 40, 40);
setPosition("playerNameG2", getProperty("playerNameG1", "x"), getProperty("playerNameG1", "y") + 10, 35, 20);
setPosition("playerNameH1", 280, 210, 40, 40);
setPosition("playerNameH2", getProperty("playerNameH1", "x"), getProperty("playerNameH1", "y") + 10, 35, 20);
setPosition("playerNameJ1", 0, 250, 40, 40);
setPosition("playerNameJ2", getProperty("playerNameJ1", "x"), getProperty("playerNameJ1", "y") + 10, 35, 20);
setPosition("playerNameK1", 40, 250, 40, 40);
setPosition("playerNameK2", getProperty("playerNameK1", "x"), getProperty("playerNameK1", "y") + 10, 35, 20);
setPosition("playerNameL1", 80, 250, 40, 40);
setPosition("playerNameL2", getProperty("playerNameL1", "x"), getProperty("playerNameL1", "y") + 10, 35, 20);
setPosition("playerNameZ1", 120, 250, 40, 40);
setPosition("playerNameZ2", getProperty("playerNameZ1", "x"), getProperty("playerNameZ1", "y") + 10, 35, 20);
setPosition("playerNameX1", 160, 250, 40, 40);
setPosition("playerNameX2", getProperty("playerNameX1", "x"), getProperty("playerNameX1", "y") + 10, 35, 20);
setPosition("playerNameC1", 200, 250, 40, 40);
setPosition("playerNameC2", getProperty("playerNameC1", "x"), getProperty("playerNameC1", "y") + 10, 35, 20);
setPosition("playerNameV1", 240, 250, 40, 40);
setPosition("playerNameV2", getProperty("playerNameV1", "x"), getProperty("playerNameV1", "y") + 10, 35, 20);
setPosition("playerNameB1", 280, 250, 40, 40);
setPosition("playerNameB2", getProperty("playerNameB1", "x"), getProperty("playerNameB1", "y") + 10, 35, 20);
setPosition("playerNameN1", 0, 290, 40, 40);
setPosition("playerNameN2", getProperty("playerNameN1", "x"), getProperty("playerNameN1", "y") + 10, 35, 20);
setPosition("playerNameM1", 40, 290, 40, 40);
setPosition("playerNameM2", getProperty("playerNameM1", "x"), getProperty("playerNameM1", "y") + 10, 35, 20);
setPosition("playerNameBackspace1", 80, 290, 120, 40);
setPosition("playerNameBackspace2", getProperty("playerNameBackspace1", "x") + 5, getProperty("playerNameBackspace1", "y") + 11, 110, 20);
setPosition("playerNameCapsLock1", 200, 290, 120, 40);
setPosition("playerNameCapsLock2", getProperty("playerNameCapsLock1", "x") + 5, getProperty("playerNameCapsLock1", "y") + 11, 110, 20);
//(Dia/Mono)logue continuation
storyElemHiding();
onEvent("dialogue(2contS0A1)", "click", function( ) {
  if (partInStory == "S0A1T1") {
    //You're an OG if you get this reference (I mean the story from the other text boxes, also referencing Sonny 2007 and the reboot game)
    setProperty("dialogue(1contS0A1)", "text", "Get some rest. Maybe you'll fare better in the afterlife...");
    partInStory = "S0A1T2";
    storyElemHiding();
  } else {
    if (partInStory == "S0A1T2") {
      setProperty("dialogue(1contS0A1)", "text", "Letting go of that sliver of life you have left will be your downfall.");
      partInStory = "S0A1T3";
      storyElemHiding();
    } else {
      if (partInStory == "S0A1T3") {
        setProperty("dialogue(1contS0A1)", "text", "Arise, " + (playerName1 + "."));
        partInStory = "S0A1T4";
        storyElemHiding();
      } else {
        
      }
    }
  }
});
function storyElemHiding() {
  showElement("dialogue(1contS0A1)");
  showElement("dialogue(2contS0A1)");
  hideElement("dialogue(txtS0A1T1)");
  hideElement("dialogue(txtS0A1T2)");
  hideElement("dialogue(txtS0A1T3)");
  hideElement("dialogue(txtS0A1T4)");
  showElement("dialogue(txt" + (partInStory + ")"));
}
//Keeping track of time for some loops
var timeMilli = 0;
var timeSecond = 0;
//Starting amount of stat points
var statPoints = 6;
//Base stat values
var strength = 5;
var agility = 5;
var constitution = 5;
var magic = 5;
var wisdom = 5;
var charisma = 5;
//Default theme is Dark, but can be changed at any time in Settings
var theme = "Dark";
//E=0, a=1, S=2, p=3, o=4, R=5, t=6, Y=7, A=8, y=9
var saveCharacterList = ["E", "a", "S", "p", "o", "R", "t", "Y", "A", "y"];
//Unsure of what to use this for right now
var Thousand = 1000;
var k = Thousand;
var Million = k * Thousand;
var m = Million;
var Billion = m * Thousand;
var b = Billion;
onEvent("startSettingsConf1", "click", function( ) {
  setScreen("statAlloc(3)");
});
onEvent("statAllocConfirm1", "click", function( ) {
  if (statPoints == 0) {
    setScreen("choosingName(4)");
  }
});
onEvent("themeChangeDark1", "click", function( ) {
  themeChangingDark();
});
onEvent("themeChangeDark2", "click", function( ) {
  themeChangingDark();
});
onEvent("themeChangeLight1", "click", function( ) {
  themeChangingLight();
});
onEvent("themeChangeLight2", "click", function( ) {
  themeChangingLight();
});
timedLoop(25, function() {
  timeMilli = getTime();
  timeSecond = Math.round(getTime() / 100) / 10;
  setProperty("startS1Label2", "text", strength);
  setProperty("startS2Label2", "text", agility);
  setProperty("startS3Label2", "text", constitution);
  setProperty("startS4Label2", "text", magic);
  setProperty("startS5Label2", "text", wisdom);
  setProperty("startS6Label2", "text", charisma);
  //If 1 stat point, "1 Stat Point" otherwise "# Stat Points"
  if (statPoints == 1) {
    setProperty("startPointsLabel1", "text", ("You have " + statPoints) + " stat point");
  } else {
    setProperty("startPointsLabel1", "text", ("You have " + statPoints) + " stat points");
  }
});
onEvent("startS1Add2", "click", function( ) {
	if (statPoints >= 1) {
	  strength = Math.round(strength + 1);
	  statPoints = Math.round(statPoints - 1);
	}
});
onEvent("startS2Add2", "click", function( ) {
	if (statPoints >= 1) {
	  agility = Math.round(agility + 1);
	  statPoints = Math.round(statPoints - 1);
	}
});
onEvent("startS3Add2", "click", function( ) {
	if (statPoints >= 1) {
	  constitution = Math.round(constitution + 1);
	  statPoints = Math.round(statPoints - 1);
	}
});
onEvent("startS4Add2", "click", function( ) {
	if (statPoints >= 1) {
	  magic = Math.round(magic + 1);
	  statPoints = Math.round(statPoints - 1);
	}
});
onEvent("startS5Add2", "click", function( ) {
	if (statPoints >= 1) {
	  wisdom = Math.round(wisdom + 1);
	  statPoints = Math.round(statPoints - 1);
	}
});
onEvent("startS6Add2", "click", function( ) {
	if (statPoints >= 1) {
	  charisma = Math.round(charisma + 1);
	  statPoints = Math.round(statPoints - 1);
	}
});
onEvent("startS1Minus2", "click", function( ) {
	if (strength >= 4) {
	  strength = Math.round(strength - 1);
	  statPoints = Math.round(statPoints + 1);
	}
});
onEvent("startS2Minus2", "click", function( ) {
	if (agility >= 4) {
	  agility = Math.round(agility - 1);
	  statPoints = Math.round(statPoints + 1);
	}
});
onEvent("startS3Minus2", "click", function( ) {
	if (constitution >= 4) {
	  constitution = Math.round(constitution - 1);
	  statPoints = Math.round(statPoints + 1);
	}
});
onEvent("startS4Minus2", "click", function( ) {
	if (magic >= 4) {
	  magic = Math.round(magic - 1);
	  statPoints = Math.round(statPoints + 1);
	}
});
onEvent("startS5Minus2", "click", function( ) {
	if (wisdom >= 4) {
	  wisdom = Math.round(wisdom - 1);
	  statPoints = Math.round(statPoints + 1);
	}
});
onEvent("startS6Minus2", "click", function( ) {
	if (charisma >= 4) {
	  charisma = Math.round(charisma - 1);
	  statPoints = Math.round(statPoints + 1);
	}
});
//Big block of code for changing color of elements with Light/Dark theme
themeChangingDark();
function themeChangingDark() {
  setProperty("startSettingsConf1", "border-color", rgb(255,255,255));
  setProperty("startSettingsConf2", "text-color", rgb(255,255,255));
  setProperty("statAllocConfirm1", "border-color", rgb(255,255,255));
  setProperty("statAllocConfirm2", "text-color", rgb(255,255,255));
  setProperty("playerNameBackspace1", "border-color", rgb(255,255,255));
  setProperty("playerNameCapsLock1", "border-color", rgb(255,255,255));
  for (var i = 0; i <= 25; i++) {
    setProperty("playerName" + (alphabetEn[i].toUpperCase() + "1"), "border-color", rgb(255,255,255));
    setProperty("playerName" + (alphabetEn[i].toUpperCase() + "1"), "text-color", rgb(255,255,255));
  }
  setProperty("choosingNameConf1", "border-color", rgb(255,255,255));
  setProperty("choosingNameConf2", "text-color", rgb(255,255,255));
  theme = "Dark";
  setProperty("titleScreen(1)", "background-color", rgb(40,40,40));
  setProperty("startSettings(2)", "background-color", rgb(40,40,40));
  setProperty("statAlloc(3)", "background-color", rgb(40,40,40));
  setProperty("statAllocBackground1", "background-color", rgb(55,55,55));
  setProperty("startSettingsTitle", "text-color", rgb(255,255,255));
  setProperty("statAllocTitle", "text-color", rgb(255,255,255));
  setProperty("mainTitle", "text-color", rgb(255,255,255));
  for (var i01 = 1; i01 < 2; i++) {
    for (var i04 = 1; i04 < 6; i++) {
      setProperty(("startS" + i04) + ("Add" + i01), "border-color", rgb(255, 255, 255));
      setProperty(("startS" + i04) + ("Add" + i01), "text-color", rgb(255, 255, 255));
    }
  }
  for (var i02 = 1; i02 < 2; i++) {
    for (var i05 = 1; i05 < 6; i++) {
      setProperty(("startS" + i05) + ("Minus" + i02), "border-color", rgb(255, 255, 255));
      setProperty(("startS" + i05) + ("Minus" + i02), "text-color", rgb(255, 255, 255));
    }
  }
  for (var i03 = 1; i03 < 3; i++) {
    for (var i06 = 1; i06 < 6; i++) {
      setProperty(("startS" + i06) + ("Label" + i03), "text-color", rgb(255, 255, 255));
    }
  }
}
function themeChangingLight() {
  setProperty("statAllocConfirm1", "border-color", rgb(0,0,0));
  setProperty("statAllocConfirm2", "text-color", rgb(0,0,0));
  setProperty("startSettingsConf1", "border-color", rgb(0,0,0));
  setProperty("startSettingsConf2", "text-color", rgb(0,0,0));
  setProperty("playerNameBackspace1", "border-color", rgb(0,0,0));
  setProperty("playerNameCapsLock1", "border-color", rgb(0,0,0));
  for (var i = 0; i <= 25; i++) {
    setProperty("playerName" + (alphabetEn[i].toUpperCase() + "1"), "border-color", rgb(0,0,0));
    setProperty("playerName" + (alphabetEn[i].toUpperCase() + "1"), "text-color", rgb(0,0,0));
  }
  setProperty("choosingNameConf1", "border-color", rgb(0,0,0));
  setProperty("choosingNameConf2", "text-color", rgb(0,0,0));
  theme = "Light";
  setProperty("titleScreen(1)", "background-color", rgb(255,255,255));
  setProperty("startSettings(2)", "background-color", rgb(255,255,255));
  setProperty("statAlloc(3)", "background-color", rgb(255,255,255));
  setProperty("statAllocBackground1", "background-color", rgb(230,230,230));
  setProperty("startSettingsTitle", "text-color", rgb(0,0,0));
  setProperty("statAllocTitle", "text-color", rgb(0,0,0));
  setProperty("mainTitle", "text-color", rgb(0,0,0));
  for (var i01 = 1; i01 < 2; i++) {
    for (var i04 = 1; i04 < 6; i++) {
      setProperty(("startS" + i04) + ("Add" + i01), "border-color", rgb(0, 0, 0));
      setProperty(("startS" + i04) + ("Add" + i01), "text-color", rgb(0, 0, 0));
    }
  }
  for (var i02 = 1; i02 < 2; i++) {
    for (var i05 = 1; i05 < 6; i++) {
      setProperty(("startS" + i05) + ("Minus" + i02), "border-color", rgb(0, 0, 0));
      setProperty(("startS" + i05) + ("Minus" + i02), "text-color", rgb(0, 0, 0));
    }
  }
  for (var i03 = 1; i03 < 3; i++) {
    for (var i06 = 1; i06 < 6; i++) {
      setProperty(("startS" + i06) + ("Label" + i03), "text-color", rgb(0, 0, 0));
    }
  }
}
